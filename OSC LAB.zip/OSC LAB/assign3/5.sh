#! /bin/bash
i=1;
while [ $i -ne 11 ]
do

`mkdir exam$i`
i=$(($i+1));

done
