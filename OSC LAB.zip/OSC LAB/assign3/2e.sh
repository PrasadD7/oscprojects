#! /bin/bash

echo "Enter a string to be reversed :" 
read str;
echo "Reversed string is"
echo $str | rev
