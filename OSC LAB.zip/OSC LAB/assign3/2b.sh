#!/bin/bash

echo "Enter a string"; read str;
strcp=$str;
echo "Copied string is $strcp";

