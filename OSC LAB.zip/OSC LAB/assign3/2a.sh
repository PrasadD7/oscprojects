#!/bin/bash
echo -n "Enter any string"; 
read str;

len=${#str}


echo "Length of string is $len";
