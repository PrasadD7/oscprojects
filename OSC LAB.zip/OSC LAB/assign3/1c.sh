res=`ps --ppid=1`

echo " $res ";
