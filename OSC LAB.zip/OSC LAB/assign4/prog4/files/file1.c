#include<stdio.h>
void a(void);
void b(void);
void c(void);
void d(void);
void main(){
a();
b();
c();
d();
}
