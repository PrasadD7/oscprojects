void c(){
printf("This is c!!!");
}           
