void d(){
printf("This is d!!!");
}     
