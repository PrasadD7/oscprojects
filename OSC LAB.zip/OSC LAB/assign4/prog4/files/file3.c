void b(){
printf("This is b!!!");
}
~            
