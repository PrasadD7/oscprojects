#include<stdio.h>
#include<unistd.h>
#include<pthread.h>
#include<semaphore.h>
int count = 0;

//pthread_mutex_t lock;

 sem_t lock;

void* func1(void *input)
{
//	pthread_mutex_lock(&lock);
	sem_wait(&lock);
		count++;
		printf("\nIn %s:count = %d\n", __func__, count);
//	pthread_mutex_unlock(&lock);
	sem_post(&lock);
	return NULL;
}

void* func2(void *input)
{

//	pthread_mutex_lock(&lock);
	sem_wait(&lock);
		count++;
		printf("\nIn %s:count = %d\n", __func__, count);
//	pthread_mutex_unlock(&lock);
	sem_post(&lock);
	return NULL;

}

void* func3(void *input)
{

//	pthread_mutex_lock(&lock);
	sem_wait(&lock);
		count++;
		printf("\nIn %s:count = %d\n", __func__, count);
//	pthread_mutex_unlock(&lock);
	sem_post(&lock);
	return NULL;

}

int main()
{
	pthread_t tid[3];

//	pthread_mutex_init(&lock, NULL);
	sem_init(&lock,0,1);

	pthread_create(&tid[0], NULL, func1, NULL);

	pthread_create(&tid[1], NULL, func2, NULL);

	pthread_create(&tid[2], NULL, func3, NULL);
	pthread_join(tid[0], NULL);
	pthread_join(tid[1], NULL);

	pthread_join(tid[2], NULL);
//	pthread_mutex_destroy(&lock);
	sem_destroy(&lock);

	return 0;

}
