
day=$(date +%u);

case $day in

1)

echo "MONDAY";;

2)

echo "TUESDAY";;

3)

echo "WEDNESDAY";;

4)

echo "THURSDAY";;

5)

echo "FRIDAY";;

6)

echo "SATURDAY";;
*)

echo "SUNDAY";;

esac
